const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
$('#year').textContent = new Date().getFullYear();

let activeCategory = 'All';
let favoritesOnly = false;
let favorites = new Set(JSON.parse(localStorage.getItem('nightshift-favorites') || '[]'));
let toastTimer;
function toast(message){const el=$('#toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2200)}
function updateFavorites(){
  $$('.game-card').forEach(card=>{
    const name=card.dataset.name, saved=favorites.has(name), btn=$('.favorite',card);
    btn.classList.toggle('saved',saved);btn.textContent=saved?'♥':'♡';btn.setAttribute('aria-pressed',String(saved));
    btn.setAttribute('aria-label',`${saved?'Remove':'Add'} ${name} ${saved?'from':'to'} favorites`);
  });
  $('#favoriteCount').textContent=favorites.size;
  $('#favoritesToggle').setAttribute('aria-pressed',String(favoritesOnly));
  $('#favoritesToggle').classList.toggle('active',favoritesOnly);
  localStorage.setItem('nightshift-favorites',JSON.stringify([...favorites]));
  filterGames();
}
function filterGames(){
  const q=$('#searchInput').value.trim().toLowerCase();let visible=0;
  $$('.game-card').forEach(card=>{
    const matchText=card.dataset.name.toLowerCase().includes(q);
    const matchCategory=activeCategory==='All'||card.dataset.category===activeCategory;
    const matchFavorite=!favoritesOnly||favorites.has(card.dataset.name);
    const show=matchText&&matchCategory&&matchFavorite;
    card.hidden=!show;if(show)visible++;
  });
  $('#emptyState').hidden=visible!==0;
  $('#gameCount').textContent=String(visible).padStart(2,'0');
}
$('#searchInput').addEventListener('input',filterGames);
$$('.filter').forEach(btn=>btn.addEventListener('click',()=>{
  activeCategory=btn.dataset.category;
  $$('.filter').forEach(b=>b.classList.toggle('active',b===btn));
  filterGames();
}));
$$('.favorite').forEach(btn=>btn.addEventListener('click',()=>{
  const name=btn.closest('.game-card').dataset.name;
  if(favorites.has(name)){favorites.delete(name);toast(`${name} removed from favorites`)}
  else{favorites.add(name);toast(`${name} saved to favorites`)}
  updateFavorites();
}));
$('#favoritesToggle').addEventListener('click',()=>{
  favoritesOnly=!favoritesOnly;
  $('#favoritesToggle').setAttribute('aria-pressed',String(favoritesOnly));
  updateFavorites();$('#games').scrollIntoView({behavior:'smooth'});
  if(favoritesOnly)toast('Showing your favorites');
});
$('#resetSearch').addEventListener('click',()=>{
  $('#searchInput').value='';activeCategory='All';favoritesOnly=false;
  $$('.filter').forEach(b=>b.classList.toggle('active',b.dataset.category==='All'));
  updateFavorites();
});
$('#surpriseBtn').addEventListener('click',()=>{
  const cards=$$('.game-card').filter(c=>!c.hidden);
  if(!cards.length){$('#resetSearch').click();toast('Filters reset — pick a game!');return}
  const card=cards[Math.floor(Math.random()*cards.length)];
  card.scrollIntoView({behavior:'smooth',block:'center'});
  card.animate([{transform:'scale(1)'},{transform:'scale(1.035)'},{transform:'scale(1)'}],{duration:450});
  toast(`Try ${card.dataset.name}!`);
});
$$('[data-runner-open]').forEach(a=>a.addEventListener('click',()=>$('#runner').scrollIntoView({behavior:'smooth'})));
$$('[data-puzzle-open]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();toast('More mini-games are coming soon!')}));

// Small built-in runner game: jump over blocks with Space, ArrowUp, or the Jump button.
const canvas=$('#runnerCanvas'), ctx=canvas.getContext('2d');
let running=false, playerY=0, velocity=0, obstacles=[], score=0, frame=0, best=Number(localStorage.getItem('nightshift-runner-best')||0);
const ground=198, player={x:70,w:22,h:28};
function resetRunner(){running=true;playerY=0;velocity=0;obstacles=[];score=0;frame=0;$('#score').textContent='0';loopRunner()}
function jump(){if(!running){resetRunner();return}if(playerY===0)velocity=-10.5}
function drawRunner(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle='#0b1020';ctx.fillRect(0,0,canvas.width,canvas.height);
  for(let i=0;i<34;i++){ctx.fillStyle=i%3===0?'#8f7aff55':'#ffffff22';ctx.fillRect((i*83+frame*.18)%canvas.width,(i*47)%155,2,2)}
  ctx.strokeStyle='#5ee7f5';ctx.shadowColor='#5ee7f5';ctx.shadowBlur=10;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,ground+1);ctx.lineTo(canvas.width,ground+1);ctx.stroke();ctx.shadowBlur=0;
  ctx.fillStyle='#a78bfa';ctx.fillRect(player.x,ground-player.h-playerY,player.w,player.h);ctx.fillStyle='#5ee7f5';ctx.fillRect(player.x+13,ground-player.h+7-playerY,5,5);
  obstacles.forEach(o=>{ctx.fillStyle='#ff78c8';ctx.shadowColor='#ff78c8';ctx.shadowBlur=12;ctx.fillRect(o.x,ground-o.h,o.w,o.h);ctx.shadowBlur=0});
  if(!running){ctx.fillStyle='#f4f5ff';ctx.textAlign='center';ctx.font='bold 18px Space Grotesk, sans-serif';ctx.fillText('NEON RUNNER',canvas.width/2,78);ctx.fillStyle='#9b9eb7';ctx.font='12px DM Mono, monospace';ctx.fillText('Press Start / Restart to play',canvas.width/2,103)}
}
function loopRunner(){
  if(!running){drawRunner();return}
  frame++;velocity+=.48;playerY-=velocity;if(playerY<0){playerY=0;velocity=0}
  if(frame%82===0)obstacles.push({x:canvas.width,w:16+Math.random()*12,h:22+Math.random()*28});
  obstacles.forEach(o=>o.x-=4.2+Math.min(score/80,3));obstacles=obstacles.filter(o=>o.x+o.w>0);
  for(const o of obstacles){if(player.x<o.x+o.w&&player.x+player.w>o.x&&ground-player.h-playerY<ground-o.h+o.h&&ground-playerY>ground-o.h){running=false;best=Math.max(best,score);localStorage.setItem('nightshift-runner-best',best);toast(`Game over! Score: ${score}`);drawRunner();return}}
  if(frame%6===0){score++;$('#score').textContent=score}
  drawRunner();requestAnimationFrame(loopRunner)
}
$('#startRunner').addEventListener('click',resetRunner);
$('#jumpBtn').addEventListener('click',jump);
canvas.addEventListener('pointerdown',jump);
document.addEventListener('keydown',e=>{
  if((e.code==='Space'||e.code==='ArrowUp')&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)){
    if($('#runner').getBoundingClientRect().top<window.innerHeight&&$('#runner').getBoundingClientRect().bottom>0){e.preventDefault();jump()}
    else if(e.code==='Slash'){ $('#searchInput').focus(); }
  }
  if(e.code==='Slash'&&document.activeElement.tagName!=='INPUT'){e.preventDefault();$('#searchInput').focus()}
});
updateFavorites();drawRunner();
