NIGHTSHIFT ARCADE — QUICK START

Files:
- index.html: page structure and game cards
- style.css: visual design and responsive layout
- app.js: search, categories, favorites, surprise button, and built-in Neon Runner mini-game

Preview locally:
1. Put all three files in the same folder.
2. Double-click index.html to open it in your browser.

Publish on Netlify:
1. Open https://app.netlify.com/drop
2. Drag the folder containing index.html, style.css, and app.js into the drop area.
3. Follow the prompts to publish and get a new URL.

To update an existing Netlify site, use its Deploys page and upload the updated site folder. If the original site is connected to Git, edit the connected project instead so later deploys don't overwrite your changes.

Notes:
- External game cards link to game/official pages; they do not bypass school or network restrictions.
- The Escape Road card currently links to a search page because the exact playable URL can vary. You can replace its href and data-url in index.html with a legitimate game page you have permission to use.
- The design uses Google Fonts if internet access is available; it falls back to local sans-serif fonts otherwise.

Updated game links: Escape Road links to escaperoad.net; Retro Bowl links to Poki. Other game cards link to official game pages where available. These are independent sites and may change their availability or embedding rules.
